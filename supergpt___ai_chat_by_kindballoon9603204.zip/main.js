import i18next from 'i18next';

async function init() {
  // DOM elements
  const chatEl = document.getElementById('chat');
  const form = document.getElementById('chat-form');
  const input = document.getElementById('message-input');
  const sendBtn = document.getElementById('send-button');
  const statusEl = document.getElementById('status');
  const langEn = document.getElementById('lang-en');
  const langEs = document.getElementById('lang-es');
  const googleSignInEl = document.getElementById('google-signin');
  const userInfoEl = document.getElementById('user-info');
  const analyzeBtn = document.getElementById('analyze-btn');
  const searchInput = document.getElementById('deep-search-input');
  const searchBtn = document.getElementById('search-button');
  const settingsBtn = document.getElementById('settings-btn');
  const prefsModal = document.getElementById('prefs-modal');
  const prefsClose = document.getElementById('prefs-close');
  const themeToggle = document.getElementById('theme-toggle');
  const fontDec = document.getElementById('font-decrease');
  const fontInc = document.getElementById('font-increase');
  const ttsToggle = document.getElementById('tts-toggle');
  const prefTts = document.getElementById('pref-tts');
  const prefAutoLang = document.getElementById('pref-auto-lang');
  const clearHistoryBtn = document.getElementById('clear-history');

  // Initialize i18next
  await i18next.init({
    lng: localStorage.getItem('sgpt_lang') || 'en',
    resources: {
      en: { translation: { placeholder: "Type your message...", send: "Send", title: "SuperGPT", connected: "Connected", disconnected: "Disconnected" } },
      es: { translation: { placeholder: "Escribe tu mensaje...", send: "Enviar", title: "SuperGPT", connected: "Conectado", disconnected: "Desconectado" } }
    }
  });

  function localize() {
    document.getElementById('title').textContent = i18next.t('title');
    input.placeholder = i18next.t('placeholder');
    sendBtn.textContent = i18next.t('send');
    const state = statusEl.dataset.state;
    statusEl.textContent = i18next.t(state);
  }
  localize();

  // Google Sign-In Setup
  google.accounts.id.initialize({
    client_id: 'YOUR_GOOGLE_CLIENT_ID',
    callback: handleGoogleSignIn
  });
  google.accounts.id.renderButton(
    googleSignInEl,
    { theme: 'outline', size: 'small', shape: 'rectangular' }
  );
  // Load saved user
  const savedUser = JSON.parse(localStorage.getItem('sgpt_user') || 'null');
  if (savedUser) showUser(savedUser);

  // Language switch
  function switchLang(lng) {
    i18next.changeLanguage(lng).then(() => {
      localStorage.setItem('sgpt_lang', lng);
      localize();
    });
  }
  langEn.addEventListener('click', () => switchLang('en'));
  langEs.addEventListener('click', () => switchLang('es'));

  // Connectivity check
  async function checkConn() {
    try {
      const r = await fetch('https://api.example.com/status');
      setConn( r.ok );
    } catch {
      setConn(false);
    }
  }
  function setConn(ok) {
    statusEl.dataset.state = ok ? 'connected' : 'disconnected';
    statusEl.className = 'status ' + (ok ? 'connected' : 'disconnected');
    statusEl.textContent = i18next.t(ok ? 'connected' : 'disconnected');
  }
  checkConn();
  setInterval(checkConn, 30000);

  // Global conversation history for AI context
  let conversationHistory = [];

  // Load conversation history using localforage for super-long memory
  let history = await localforage.getItem('sgpt_history') || [];
  history.forEach(m => {
    appendMsg(m.sender, m.text);
    const role = m.sender === 'user' ? 'user' : 'assistant';
    conversationHistory.push({ role, content: m.text });
  });
  scrollBottom();

  // Preferences handlers
  settingsBtn.addEventListener('click', () => {
    prefsModal.classList.remove('hidden');
    prefsModal.setAttribute('aria-hidden','false');
  });
  prefsClose.addEventListener('click', () => {
    prefsModal.classList.add('hidden');
    prefsModal.setAttribute('aria-hidden','true');
  });
  themeToggle.addEventListener('click', () => {
    const dark = body.classList.toggle('dark-mode');
    localStorage.setItem('pref_theme', dark ? 'dark' : 'light');
  });
  fontDec.addEventListener('click', () => {
    let size = parseInt(localStorage.getItem('pref_font_size')) || 100;
    size = Math.max(80, size - 10);
    document.documentElement.style.fontSize = size + '%';
    localStorage.setItem('pref_font_size', size);
  });
  fontInc.addEventListener('click', () => {
    let size = parseInt(localStorage.getItem('pref_font_size')) || 100;
    size = Math.min(150, size + 10);
    document.documentElement.style.fontSize = size + '%';
    localStorage.setItem('pref_font_size', size);
  });
  ttsToggle.addEventListener('click', () => {
    ttsEnabled = !ttsEnabled;
    localStorage.setItem('pref_tts', ttsEnabled);
    ttsToggle.textContent = ttsEnabled ? '🔊' : '🔈';
  });
  prefTts.addEventListener('change', () => {
    ttsEnabled = prefTts.checked;
    localStorage.setItem('pref_tts', ttsEnabled);
    ttsToggle.textContent = ttsEnabled ? '🔊' : '🔈';
  });
  prefAutoLang.addEventListener('change', () => {
    autoLangEnabled = prefAutoLang.checked;
    localStorage.setItem('pref_auto_lang', autoLangEnabled);
  });
  clearHistoryBtn.addEventListener('click', async () => {
    await localforage.removeItem('sgpt_history');
    history = []; conversationHistory = []; chatEl.innerHTML = '';
  });

  // Form submit
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const txt = input.value.trim();
    if (!txt) return;
    input.value = '';
    appendMsg('user', txt);
    save('user', txt);
    scrollBottom();
    sendBtn.disabled = true;
    const reply = await getAIReply(txt);
    appendMsg('ai', reply);
    save('ai', reply);
    scrollBottom();
    sendBtn.disabled = false;
    new Audio('message-sent.mp3').play();
    if (ttsEnabled) {
      try {
        const ttsRes = await websim.textToSpeech({ text: reply, voice: 'en-female' });
        new Audio(ttsRes.url).play();
      } catch {}
    }
  });

  function appendMsg(sender, text) {
    const div = document.createElement('div');
    div.className = 'message ' + sender;
    div.textContent = text;
    chatEl.appendChild(div);
  }
  function save(sender, text) {
    history.push({ sender, text });
    localforage.setItem('sgpt_history', history);
  }
  function scrollBottom() {
    chatEl.scrollTop = chatEl.scrollHeight;
  }

  // Deep Search Handler
  searchBtn.addEventListener('click', handleDeepSearch);
  searchInput.addEventListener('keypress', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleDeepSearch();
    }
  });
  async function handleDeepSearch() {
    const q = searchInput.value.trim();
    if (!q) return;
    searchInput.value = '';
    appendMsg('user', `Search: ${q}`);
    scrollBottom();
    try {
      const res  = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json`);
      const data = await res.json();
      const text = data.AbstractText || (data.RelatedTopics && data.RelatedTopics[0]?.Text) || 'No results found.';
      appendMsg('ai', `Deep Search Result: ${text}`);
    } catch (err) {
      appendMsg('ai', `Deep Search Error: ${err.message}`);
    }
    scrollBottom();
    new Audio('message-sent.mp3').play();
  }

  // Deep Analysis Handler
  analyzeBtn.addEventListener('click', () => {
    const totalMessages = history.length;
    const userMsgs      = history.filter(m => m.sender === 'user').length;
    const aiMsgs        = history.filter(m => m.sender === 'ai').length;
    const totalWords    = history.reduce((acc, m) => acc + m.text.split(/\s+/).length, 0);
    const avgWords      = totalMessages ? (totalWords / totalMessages).toFixed(2) : 0;
    const analysisText  = `Deep Analysis:
    Total messages: ${totalMessages}
    User messages: ${userMsgs}
    AI messages: ${aiMsgs}
    Total words: ${totalWords}
    Avg words/msg: ${avgWords}`;
    appendMsg('analysis', analysisText);
    scrollBottom();
  });

  // Google Sign-In Callbacks
  function handleGoogleSignIn(response) {
    const jwt     = response.credential;
    const payload = JSON.parse(atob(jwt.split('.')[1]));
    const { name, picture, email } = payload;
    localStorage.setItem('sgpt_user', JSON.stringify({ name, picture, email }));
    showUser({ name, picture, email });
  }
  function showUser({ name, picture, email }) {
    googleSignInEl.classList.add('hidden');
    userInfoEl.classList.remove('hidden');
    userInfoEl.innerHTML = `<img src="${picture}" alt="${name}" class="avatar"/><span>${name}</span><button id="signout-btn">Sign Out</button>`;
    document.getElementById('title').textContent = `${i18next.t('title')} (${name})`;
    document.getElementById('title').title = email;
    document.getElementById('signout-btn').addEventListener('click', () => {
      localStorage.removeItem('sgpt_user');
      userInfoEl.classList.add('hidden');
      googleSignInEl.classList.remove('hidden');
      document.getElementById('title').textContent = i18next.t('title');
    });
  }

  // Simulated AI backend
  async function getAIReply(input) {
    const systemPrompt = "You are SuperGPT, an advanced, friendly and helpful AI assistant.";
    conversationHistory.push({ role: 'user', content: input });
    const messages = [{ role: 'system', content: systemPrompt }, ...conversationHistory.slice(-10)];
    try {
      const completion = await websim.chat.completions.create({ messages });
      const reply = completion.choices?.[0]?.message?.content || completion.content || '';
      conversationHistory.push({ role: 'assistant', content: reply });
      return reply;
    } catch (err) {
      return "Error getting AI response: " + err.message;
    }
  }
}

init();